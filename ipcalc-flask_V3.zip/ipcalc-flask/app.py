from flask import Flask, request, jsonify, render_template
from ipaddress import ip_network, ip_address, IPv4Network

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")
    
@app.route("/calculer", methods=["POST"])
def calculer():
    data = request.get_json()
    ip_str = data.get("ip")
    cidr = int(data.get("cidr", 24))

    try:
        ip_net = ip_network(f"{ip_str}/{cidr}", strict=False)
        ip = ip_address(ip_str)

        if ip.version == 4:
            network = IPv4Network(f"{ip_str}/{cidr}", strict=False)
            reseau = str(network.network_address)
            broadcast = str(network.broadcast_address)
            masque = str(network.netmask)
            hôtes = network.num_addresses - 2 if network.num_addresses > 2 else network.num_addresses
            plage = f"{network.network_address + 1} → {network.broadcast_address - 1}"

            return jsonify({
                "type": "IPv4",
                "adresse_reseau": reseau,
                "adresse_broadcast": broadcast,
                "masque": masque,
                "hotes_possibles": hôtes,
                "plage": plage
            })
        else:
            total = ip_net.num_addresses
            prefix = ip_net.prefixlen
            return jsonify({
                "type": "IPv6",
                "total_adresses": total,
                "prefix": prefix
            })

    except Exception as e:
        return jsonify({"error": f"Erreur de calcul IP : {str(e)}"}), 400

if __name__ == "__main__":
    app.run(debug=True)