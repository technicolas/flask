function autoRemplir() {
  const val = document.getElementById("suggestion").value;
  if (val) {
    const [ip, cidr] = val.split('/');
    document.getElementById("ip").value = ip;
    document.getElementById("cidr").value = cidr;
  }
}

function ipToBinary(ip) {
  if (ip.includes(":")) return "Format IPv6 non pris en charge en binaire.";
  const octets = ip.split('.');
  if (octets.length !== 4) return "IP invalide";

  return octets.map(o => {
    const val = parseInt(o);
    return (val >= 0 && val <= 255)
      ? val.toString(2).padStart(8, '0')
      : "???????";
  }).join('.');
}

function maskToBinary(cidr) {
  let mask = ''.padStart(cidr, '1').padEnd(32, '0');
  return mask.match(/.{1,8}/g).join('.');
}

function colorBinary(bits, cidr) {
  const binary = bits.replace(/\./g, '');
  const segments = [...binary].map((bit, i) => {
    return i < cidr
      ? `<span style="color: #00BFFF;">${bit}</span>`  // Réseau en bleu
      : `<span style="color: gold;">${bit}</span>`     // Hôte en jaune
  });

  const groups = [];
  for (let i = 0; i < segments.length; i += 8) {
    groups.push(segments.slice(i, i + 8).join(''));
  }

  return groups.join('.');
}

function calculerSousReseaux(cidrBase, cidrFinal) {
  if (cidrFinal < cidrBase) {
    return `Erreur : le CIDR cible doit être ≥ au CIDR de base.`;
  }
  return Math.pow(2, cidrFinal - cidrBase);
}

function calculerAdressesParSousReseau(cidrFinal) {
  return Math.pow(2, 32 - cidrFinal);
}

async function calculer() {
  const ip = document.getElementById("ip").value.trim();
  const cidr = parseInt(document.getElementById("cidr").value);
  const cidrFinal = parseInt(document.getElementById("cidrFinal").value);

  const res = await fetch("/calculer", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ip, cidr })
  });

  const data = await res.json();
  let out = "";

  if (data.error) {
    out = data.error;
  } else if (data.type === "IPv4") {
    const ipBin = colorBinary(ipToBinary(ip), cidr);
    const maskBin = colorBinary(maskToBinary(cidr), cidr);
    const reseauBin = colorBinary(ipToBinary(data.adresse_reseau), cidr);
    const broadcastBin = colorBinary(ipToBinary(data.adresse_broadcast), cidr);

    const nbSousReseaux = calculerSousReseaux(cidr, cidrFinal);
    const nbAdresses = calculerAdressesParSousReseau(cidrFinal);

    out = `${ip} /${cidr} est une adresse IPv4

Adresse IP : ${ip}
→ Binaire : ${ipBin}

Masque décimal : ${data.masque} → Masque CIDR : /${cidr}
→ Binaire : ${maskBin}

Adresse Réseau : ${data.adresse_reseau}
→ Binaire : ${reseauBin}

Adresse Broadcast : ${data.adresse_broadcast}
→ Binaire : ${broadcastBin}

* Plage IP utilisable : ${data.plage}
* Nombre d'hôtes possibles : ${data.hotes_possibles}`;

    if (typeof nbSousReseaux === "string") {
      out += `\n\n→ ${nbSousReseaux} (CIDR cible : /${cidrFinal})`;
    } else {
      out += `\n\n* Nombre de sous-réseaux en /${cidrFinal} : ${nbSousReseaux}`;
      out += `\n* Adresses par sous-réseau (/ ${cidrFinal}) : ${nbAdresses}`;
    }

  } else if (data.type === "IPv6") {
    out = `${ip} est une adresse IPv6
Préfixe : /${data.prefix}
Nombre total d'adresses : ${data.total_adresses}`;
  }

  document.getElementById("resultat").innerHTML = out;
}
